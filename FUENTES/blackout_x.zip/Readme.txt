Fonts -- (c) 1998 - 2000 'ck!' [Freaky Fonts]

These fonts are freeware, for personal, non-commercial use!
These font files may not be modified and this readme file must be 
included with each font.

This zip includes Windows bitmap-fonts (*.fon).

Visit ..::Freaky Fonts::.. for updates and new fonts (PC & MAC):
http://www.freakyfonts.de

You like the fonts?, comments, problems, bugs, suggestions? e-mail: 
ckrule@geocities.com


 